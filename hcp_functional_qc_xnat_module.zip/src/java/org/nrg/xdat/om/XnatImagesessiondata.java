/*
 * GENERATED FILE
 * Created on Wed Jun 24 02:12:54 CDT 2015
 *
 */
package org.nrg.xdat.om;
import org.nrg.xft.*;
import org.nrg.xdat.om.*;
import org.nrg.xdat.om.base.*;
import org.nrg.xft.security.UserI;
import org.nrg.xft.exception.*;
import org.nrg.xft.search.TableSearch;
import org.nrg.xft.utils.StringUtils;
import org.nrg.xdat.base.BaseElement;
import org.nrg.xnat.scanAssessors.ScanAssessorI;
import org.nrg.xdat.model.*;

import java.util.*;


/**
 * @author XDAT
 *
 */
@SuppressWarnings({"unchecked","rawtypes"})
public class XnatImagesessiondata extends BaseXnatImagesessiondata {

	protected List<XnatImageassessordataI> sortedMinLoadAssessors = null;


	public XnatImagesessiondata(ItemI item)
	{
		super(item);
	}

	public XnatImagesessiondata(UserI user)
	{
		super(user);
	}

	/*
	 * @deprecated Use BaseXnatImagesessiondata(UserI user)
	 **/
	public XnatImagesessiondata()
	{}

	public XnatImagesessiondata(Hashtable properties, UserI user)
	{
		super(properties,user);
	}


    public List<XnatImageassessordataI> getSortedMinimalLoadAssessors()
    {
        if (sortedMinLoadAssessors==null)
        {
            sortedMinLoadAssessors = new ArrayList<XnatImageassessordataI>();
            if(getItem().isPreLoaded())
            {
                sortedMinLoadAssessors=this.getAssessors();
            }else{

                try {
                    XFTTable table = TableSearch.Execute("SELECT to_number(substring(ex.id from '%SCAN#\"[0-9]*#\"%' for '#'), '9999999999') AS scan, ex.id,ex.date,ex.project,me.element_name AS type,me.element_name,ex.note AS note,i.lastname, investigator_xnat_investigatorData_id AS invest_id,projects " +
                            "FROM xnat_imageAssessorData assessor " +
                            "LEFT JOIN xnat_experimentData ex ON assessor.ID=ex.ID " +
                            "LEFT JOIN xnat_investigatorData i ON i.xnat_investigatorData_id=ex.investigator_xnat_investigatorData_id " +
                            "LEFT JOIN xdat_meta_element me ON ex.extension=me.xdat_meta_element_id " +
                            "LEFT JOIN (SELECT xs_a_concat(project || ',') AS PROJECTS, sharing_share_xnat_experimentda_id FROM xnat_experimentData_share GROUP BY sharing_share_xnat_experimentda_id) PROJECT_SEARCH " +
                            "ON ex.id=PROJECT_SEARCH.sharing_share_xnat_experimentda_id WHERE assessor.imagesession_id='" + this.getId() +"' ORDER BY scan ASC",getDBName(),null);
                    table.resetRowCursor();

                    while (table.hasMoreRows())
                    {
                        Hashtable row = table.nextRowHash();
                        String element = (String)row.get("element_name");
                        try {
                            XFTItem child = XFTItem.NewItem(element,this.getUser());

                            Object date = row.get("date");
                            Object id = row.get("id");
                            Object note = row.get("note");
                            Object invest_id = row.get("invest_id");
                            Object lastname = row.get("lastname");
                            Object project = row.get("project");

                            if (date!=null)
                            {
                                try {
                                    child.setProperty("date",date);
                                } catch (XFTInitException e) {
                                    logger.error("",e);
                                } catch (ElementNotFoundException e) {
                                    logger.error("",e);
                                } catch (FieldNotFoundException e) {
                                    logger.error("",e);
                                } catch (InvalidValueException e) {
                                    logger.error("",e);
                                }
                            }
                            if (id!=null)
                            {
                                try {
                                    child.setProperty("ID",id);
                                } catch (XFTInitException e) {
                                    logger.error("",e);
                                } catch (ElementNotFoundException e) {
                                    logger.error("",e);
                                } catch (FieldNotFoundException e) {
                                    logger.error("",e);
                                } catch (InvalidValueException e) {
                                    logger.error("",e);
                                }
                            }

                            if (project!=null)
                            {
                                try {
                                    child.setProperty("project",project);
                                } catch (XFTInitException e) {
                                    logger.error("",e);
                                } catch (ElementNotFoundException e) {
                                    logger.error("",e);
                                } catch (FieldNotFoundException e) {
                                    logger.error("",e);
                                } catch (InvalidValueException e) {
                                    logger.error("",e);
                                }
                            }

                            if (note!=null)
                            {
                                try {
                                    child.setProperty("note",note);
                                } catch (XFTInitException e) {
                                    logger.error("",e);
                                } catch (ElementNotFoundException e) {
                                    logger.error("",e);
                                } catch (FieldNotFoundException e) {
                                    logger.error("",e);
                                } catch (InvalidValueException e) {
                                    logger.error("",e);
                                }
                            }
                            if (lastname!=null)
                            {
                                try {
                                    child.setProperty("investigator.lastname",lastname);
                                } catch (XFTInitException e) {
                                    logger.error("",e);
                                } catch (ElementNotFoundException e) {
                                    logger.error("",e);
                                } catch (FieldNotFoundException e) {
                                    logger.error("",e);
                                } catch (InvalidValueException e) {
                                    logger.error("",e);
                                }
                            }
                            if (invest_id!=null)
                            {
                                try {
                                    child.setProperty("investigator_xnat_investigatorData_id",invest_id);
                                } catch (XFTInitException e) {
                                    logger.error("",e);
                                } catch (ElementNotFoundException e) {
                                    logger.error("",e);
                                } catch (FieldNotFoundException e) {
                                    logger.error("",e);
                                } catch (InvalidValueException e) {
                                    logger.error("",e);
                                }
                            }

                            String projects = (String)row.get("projects");
                            if (projects!=null)
                            {
                                Iterator iter= StringUtils.CommaDelimitedStringToArrayList(projects, true).iterator();
                                while(iter.hasNext())
                                {
                                    String projectName = (String)iter.next();
                                    child.setProperty("sharing.share.project", projectName);
                                }
                            }

                            XnatImageassessordata assessor= (XnatImageassessordata)BaseElement.GetGeneratedItem(child);

                            if (element.equalsIgnoreCase(XnatQcmanualassessordata.SCHEMA_ELEMENT_NAME))
                            {
                                if (this.manQC == null)
                                {
                                    if (this.getUser().canRead(child))
                                    {
                                        this.manQC = new XnatQcmanualassessordata(child.getCurrentDBVersion(false));
                                        sortedMinLoadAssessors.add(this.manQC);
                                    }else{
                                        sortedMinLoadAssessors.add(new XnatQcmanualassessordata(child));
                                    }
                                }else{
                                    this.manQC = new XnatQcmanualassessordata(child.getCurrentDBVersion(false));
                                    sortedMinLoadAssessors.add(this.manQC);
                                }
                            }else if (element.equalsIgnoreCase(XnatQcassessmentdata.SCHEMA_ELEMENT_NAME))
                            {
                                if (this.qc == null)
                                {
                                    if (this.getUser().canRead(child))
                                    {
                                        this.qc = new XnatQcassessmentdata(child.getCurrentDBVersion(false));
                                        sortedMinLoadAssessors.add(this.qc);
                                    }else{
                                        sortedMinLoadAssessors.add(new XnatQcassessmentdata(child));
                                    }
                                }else{
                                    this.qc = new XnatQcassessmentdata(child.getCurrentDBVersion(false));
                                    sortedMinLoadAssessors.add(this.qc);
                                }
                            }else if(assessor instanceof ScanAssessorI){
                                sortedMinLoadAssessors.add( (XnatImageassessordata)BaseElement.GetGeneratedItem(child.getCurrentDBVersion(false)));
                            }else{
                                sortedMinLoadAssessors.add(assessor);
                            }

                        } catch (XFTInitException e) {
                            logger.error("",e);
                        } catch (ElementNotFoundException e) {
                            logger.error("",e);
                        }
                    }
                } catch (Exception e) {
                    logger.error("",e);
                }
            }
        }

        return sortedMinLoadAssessors;
    }


}
